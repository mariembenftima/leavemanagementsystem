export class PerformanceRepository {
  async getLatestPerformance(userId: any) { return null; }
  async createPerformance(dto: any) { return { toOverview: () => ({}) }; }
}
