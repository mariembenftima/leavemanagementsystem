export enum Gender {
  MALE = 'male',
  FEMALE = 'female',
  OTHER = 'other',
}
