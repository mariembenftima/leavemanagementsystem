export enum LeaveBalanceType {
  ANNUAL = 'annual',
  SICK = 'sick',
  PERSONAL = 'personal',
}
