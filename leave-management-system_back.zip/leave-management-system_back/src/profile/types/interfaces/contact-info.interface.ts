export interface IContactInfo {
  email: string;
  phone?: string;
  emergencyContact?: string;
  currentAddress?: string;
}
