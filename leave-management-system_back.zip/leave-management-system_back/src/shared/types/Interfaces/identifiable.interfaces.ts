export interface IIdentifiable {
  id: string;
  createdAt: Date;
  updatedAt: Date;
}
