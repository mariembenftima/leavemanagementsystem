export interface TeamDao {
  id: number;
  name: string;
}
