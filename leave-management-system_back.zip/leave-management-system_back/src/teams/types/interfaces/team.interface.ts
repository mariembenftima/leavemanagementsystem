export interface Team {
  id: number;
  name: string;
  memberIds?: number[]; // optional convenience projectio
}
