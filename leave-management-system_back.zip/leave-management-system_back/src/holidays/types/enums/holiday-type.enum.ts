export enum HolidayType {
  NATIONAL = 'national',
  RELIGIOUS = 'religious',
  COMPANY = 'company',
  OPTIONAL = 'optional',
}
