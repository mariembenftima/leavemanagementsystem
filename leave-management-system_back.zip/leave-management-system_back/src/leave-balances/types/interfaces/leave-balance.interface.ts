export interface LeaveBalance {
  id: number;
  userId: number;
  leaveTypeId: number;
  year: number;
  carryover: number;
  used: number;
}
