// import { Injectable } from '@nestjs/common';
// import { DataSource, Repository } from 'typeorm';
// import { User } from '../entities/auth.entity';

// @Injectable()
// export class UsersRepository extends Repository<User> {
//   constructor(private dataSource: DataSource) {
//     super(
//       User,
//       dataSource.createEntityManager(),
//       dataSource.createQueryRunner(),
//     );
//   }

//   // Additional methods for user-specific queries can be added here
// }
