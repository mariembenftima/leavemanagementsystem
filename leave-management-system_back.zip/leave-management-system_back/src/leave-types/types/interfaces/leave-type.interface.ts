export interface LeaveType {
  id: number;
  name: string;
  maxDays: number;
}
