export interface LeaveTypeDao {
  id: number;
  name: string;
  maxDays: number;
}
